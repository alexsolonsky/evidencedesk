"""Print selected fields from actual local demo artifacts, without rewriting them."""
import argparse,json,textwrap
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('part',choices=['evidence','claim','provenance','prepare-validation']);p.add_argument('--index',type=int,default=0);a=p.parse_args()
def say(value):
    for line in str(value).splitlines() or ['']:
        print(textwrap.fill(line,width=94,replace_whitespace=False,drop_whitespace=False))
if a.part=='evidence':
    pack=json.loads(Path('demo/evidence.json').read_text())
    print('DETERMINISTIC EVIDENCE / SYNTHETIC DIFF')
    for file in pack['files']:
        print('File:',file['new_path'],' | status:',file['status'])
        for side,key in [('old','removed_lines'),('new','added_lines')]:
            for line in file[key]:
                print(f"{side} line {line[side+'_line']}: {line['text']}")
                print('ID:',line['evidence_id'])
else:
    result=json.loads(Path('demo/live-review.json').read_text())
    if a.part=='claim':
        c=result['review']['claims'][a.index]
        print('ACTUAL RESPONSE / CLAIM',a.index+1)
        say(c['claim']);print('Status:',c['status']);say('Rationale: '+c['rationale'])
        for eid in c['evidence_ids']:
            e=result['evidence_index'][eid]
            print(eid);say(f"  {e['path']} | {e['side']} line {e['line']}: {e['text']}")
    elif a.part=='provenance':
        v=result['provenance']
        print('ACTUAL RUN PROVENANCE')
        for key in ['kind','model','created_at','elapsed_seconds','cloud_used','fixture_response_substituted','semantic_truth_checked']:
            print(key+':',v.get(key))
        print('system_prompt_sha256:',v['system_prompt_sha256'])
        print('Stored raw result: demo/live-review.json')
    else:
        review=result['review']
        assert result['validation']['structurally_valid'],'Actual response did not pass structure'
        Path('demo/valid-review.json').write_text(json.dumps(review,indent=2)+'\n')
        invalid=json.loads(json.dumps(review))
        assert invalid['claims'],'Actual response has no claims to mutate'
        invalid['claims'][0]['evidence_ids']=['E-DEMO-UNKNOWN-REFERENCE']
        Path('demo/invalid-review.json').write_text(json.dumps(invalid,indent=2)+'\n')
        print('Valid review extracted unchanged from the actual model response.')
        print('Separate negative control: first claim citation intentionally replaced.')
        print('Invalid ID: E-DEMO-UNKNOWN-REFERENCE')
        print('Original live-review.json remains unchanged.')
