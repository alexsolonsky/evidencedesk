# EvidenceDesk — actual CLI demonstration

The finished video is `evidencedesk-cli-demo.mp4`: 3 minutes 40 seconds, 1920×1080,
24 fps, H.264, English explanatory cards/captions, no audio. It is a rendered replay of
**actual timestamped subprocess output**, not a screen capture or browser UI recording.
The separate browser demonstration remains outstanding.

The synthetic source is `input.diff`. The scripted capture ran the actual evidence
extractor, invoked the already installed local qwen3.6:35b model, inspected the returned
claim and exact source records, and executed the validator on both the unmodified
review and a deliberately invalid citation. No saved model answer was substituted.

- Actual capture: 83.900714 seconds, including explicitly recorded reading pauses.
- Actual local inference: 8.368 seconds; one returned claim cites both old/new line 20.
- Good response: structural validation true, process exit 0.
- Deliberately unknown ID: structural validation false, expected process exit 1.
- The unknown-ID review is a labeled negative control, not an extra model output.
- The original model JSON remains unchanged.

The observation correctly states that `or allow_preview` was added to the retained
`user.is_admin` check. This manual comparison was performed by the implementing AI
assistant. It does not establish deployed security or general accuracy. This new demo
run is separate from the prior nine-response synthetic QA batch; those historical
counts have not been changed.

## Inspectable artifacts

`recording.cast` is asciicast v2 output. `events.jsonl` preserves monotonic timestamps,
actual argv, stdout/stderr output, process exit codes and reading-pause events.
`terminal-transcript.txt` is a readable derivation of that same event log.
`capture-metadata.json` summarizes the command timings and expected exits.
`live-review.json` is the actual model result with evidence and provenance.
`valid-review.json` extracts its review object unchanged; `invalid-review.json` replaces
the first claim's evidence-ID list with one deliberately unknown ID. `validation-valid.json` and `validation-invalid.json` are
saved directly from the recorded validator stdout, not a later simulated response.

`render-timeline.json` maps the replay into the video. The original capture starts at
36.000 seconds and ends at approximately 119.917 seconds, at its original speed.
All other scenes are explanatory cards. Event timing is quantized conservatively within
two 24-fps frames by the terminal renderer; unrounded source timestamps are retained.
The displayed terminal is rendered text, with screen-clears and line wrapping; it is
not a mock browser interface. `transcript.md` contains the explanatory card text.

`capture_cli.py`, `inspect_demo.py` and `render_demo.py` document the production method.
Capture requires the EvidenceDesk app code in the parent directory and the existing
local model; it refuses to overwrite the original run. Rendering uses Pillow, ffmpeg,
and locally available Menlo/Arial fonts. No dependencies/models were downloaded and no
paid generation service was used. Application and release files were not modified.

The lightweight replay pack intentionally omits the video, temporary rendered PNGs,
and private machine paths. The video is distributed separately. The manifest includes
its exact size/hash and inventories every replay-pack file except the manifest itself.
Checksums provide integrity evidence, not a signed authenticity or semantic guarantee.
