"""Capture real subprocess output and event timing into asciicast v2 and JSONL."""
import datetime,json,os,select,shlex,subprocess,time
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
os.chdir(ROOT)
for p in ['demo/recording.cast','demo/events.jsonl','demo/live-review.json']:
    if Path(p).exists():raise SystemExit('Refusing to replace prior demo artifact: '+p)
start=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc)
cast=Path('demo/recording.cast').open('w');events=Path('demo/events.jsonl').open('w');commands=[]
cast.write(json.dumps({'version':2,'width':110,'height':28,'timestamp':int(started.timestamp()),'title':'EvidenceDesk actual CLI capture - synthetic input - local inference','env':{'TERM':'xterm-256color'}})+'\n');cast.flush()
def event(kind,**data):
    obj={'t':round(time.monotonic()-start,6),'kind':kind,**data};events.write(json.dumps(obj)+'\n');events.flush();return obj['t']
def out(text,kind='recorder_annotation'):
    t=event(kind,text=text);cast.write(json.dumps([t,'o',text.replace('\n','\r\n')])+'\n');cast.flush()
def pause(seconds):
    event('reading_pause',seconds=seconds);time.sleep(seconds)
def run(argv,expected=0,hold=5):
    out('\x1b[2J\x1b[H')
    out('EvidenceDesk $ '+shlex.join(argv)+'\n','command_display')
    begin=event('command_start',argv=argv,expected_exit=expected)
    process=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    chunks=[]
    while True:
        ready=select.select([process.stdout],[],[],0.2)[0]
        if ready:
            raw=os.read(process.stdout.fileno(),65536)
            if raw:
                text=raw.decode('utf8',errors='replace');chunks.append(text);out(text,'subprocess_output')
            elif process.poll() is not None:break
        elif process.poll() is not None:break
    code=process.wait();duration=round(time.monotonic()-start-begin,6)
    out(f'\n[process exit {code}; elapsed {duration:.3f} s]\n','process_status')
    event('command_exit',argv=argv,exit_code=code,duration_seconds=duration)
    commands.append({'argv':argv,'started_at':begin,'elapsed_seconds':duration,'exit_code':code,'expected_exit':expected})
    if code!=expected:raise RuntimeError('Unexpected process exit '+str(code))
    pause(hold)
try:
    out('ACTUAL CLI CAPTURE / SYNTHETIC INPUT\nNo saved response substitutes for live inference.\n');pause(2)
    run(['cat','fixtures/semantic-v2/context-limits.diff'],hold=9)
    run(['python3','evidence_pack.py','fixtures/semantic-v2/context-limits.diff','--json','demo/evidence.json','--markdown','demo/evidence.md'],hold=3)
    run(['python3','demo/inspect_demo.py','evidence'],hold=10)
    run(['python3','local_review.py','fixtures/semantic-v2/context-limits.diff','--model','qwen3.6:35b','--output','demo/live-review.json'],hold=4)
    live=json.loads(Path('demo/live-review.json').read_text())
    for i in range(len(live['review']['claims'])):
        run(['python3','demo/inspect_demo.py','claim','--index',str(i)],hold=11)
    run(['python3','demo/inspect_demo.py','provenance'],hold=9)
    run(['python3','demo/inspect_demo.py','prepare-validation'],hold=7)
    run(['python3','validate_review.py','demo/evidence.json','demo/valid-review.json'],hold=9)
    run(['python3','validate_review.py','demo/evidence.json','demo/invalid-review.json'],expected=1,hold=11)
    event('capture_complete')
    duration=round(time.monotonic()-start,6)
    Path('demo/capture-metadata.json').write_text(json.dumps({'kind':'actual_subprocess_cli_capture','started_at':started.isoformat(),'duration_seconds':duration,'synthetic_input':True,'live_model_invoked':True,'model':'qwen3.6:35b','browser_ui_capture':False,'commands':commands},indent=2)+'\n')
    print(json.dumps({'capture_seconds':duration,'claim_count':len(live['review']['claims']),'structurally_valid':live['validation']['structurally_valid'],'actual_inference_seconds':live['provenance']['elapsed_seconds']},indent=2),flush=True)
finally:
    cast.close();events.close()
