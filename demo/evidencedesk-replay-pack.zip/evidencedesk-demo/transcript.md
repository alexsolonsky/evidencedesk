# EvidenceDesk CLI demonstration transcript

Actual timestamped terminal output is replayed at its original speed. This is not browser footage.

## 0.00–18.00s · EVIDENCEDESK
Every claim. A line to inspect.

Local AI code review with exact source evidence.

A CLI demonstration using synthetic input and actual local inference.

Terminal output is replayed at its original recorded timing.

## 18.00–36.00s · THE EXAMPLE
A small change. A real boundary.

Old:  if user.is_admin:

New: if user.is_admin or allow_preview:

The text changed. The diff alone does not establish deployed access behavior.

This is a terminal replay, not a browser UI recording.

## 36.00–119.92s · ACTUAL CLI REPLAY

The original timestamped capture is replayed at 1× speed, including its recorded reading
pauses and actual model wait. It shows the synthetic diff, evidence extraction, real
local inference, the returned claim and provenance, unchanged-review validation, and
expected rejection of a separate unknown-ID negative control. Exact output and timings
are preserved in recording.cast and events.jsonl; no browser footage is represented.

## 119.92–144.94s · THE ACTUAL RESPONSE
Observe the change. Inspect both sources.

One real qwen3.6:35b invocation completed in 8.368 seconds.

The returned observation cites the old and new line 20.

It describes adding “or allow_preview” while retaining the existing check.

This is one observed run, not a performance or accuracy guarantee.

## 144.94–169.96s · THE VALIDATOR
A valid citation is not proof of truth.

The actual response passed schema and reference validation.

A separate, deliberately changed citation used an unknown evidence ID.

The validator rejected that negative control with exit code 1.

The original model response remained unchanged.

## 169.96–194.98s · SCOPE & PROVENANCE
The limits stay visible.

Changed text and exact coordinates; no repository code execution.

No binary-content review, test execution or security certification.

Exports preserve the response, evidence, validation and model provenance.

Development QA uses synthetic examples and retained failures, not an independent benchmark.

## 194.98–220.00s · LOCAL PROTOTYPE
Keep the evidence. Keep the final judgment.

Missing local runtime means inference unavailable; there is no cloud fallback.

Broader evaluation, a reviewer study and full accessibility testing remain.

The source cast, event log and actual result accompany this demonstration.

EvidenceDesk · CLI demonstration · synthetic input · actual local inference
