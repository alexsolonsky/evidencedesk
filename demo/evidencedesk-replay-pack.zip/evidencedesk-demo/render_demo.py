"""Render actual timestamped stdout as a clearly labeled terminal replay, plus explanatory cards."""
import bisect,hashlib,json,math,re,subprocess,textwrap
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont

ROOT=Path(__file__).resolve().parent
W,H,FPS=1920,1080,24
BG='#081512';PANEL='#101f1b';INK='#eef7f2';MUTED='#a7bab0';ACCENT='#a4efc1'
MONO='/System/Library/Fonts/Menlo.ttc';SANS='/System/Library/Fonts/Supplemental/Arial.ttf';BOLD='/System/Library/Fonts/Supplemental/Arial Bold.ttf'
font=lambda n,b=False:ImageFont.truetype(BOLD if b else SANS,n)
mono=ImageFont.truetype(MONO,24)
meta=json.loads((ROOT/'capture-metadata.json').read_text());live=json.loads((ROOT/'live-review.json').read_text())
events=[json.loads(s) for s in (ROOT/'events.jsonl').read_text().splitlines()]
cast=[json.loads(s) for s in (ROOT/'recording.cast').read_text().splitlines()][1:]
cap=math.ceil(meta['duration_seconds']*FPS)/FPS
intro=36.;total=max(220.,intro+cap+64.)
assert total<=240,'Capture too long for four-minute edition; preserve the cast and inspect timeline'
post=total-intro-cap
cards=[(0.,18.,'EVIDENCEDESK','Every claim.\nA line to inspect.',
 ['Local AI code review with exact source evidence.','A CLI demonstration using synthetic input and actual local inference.','Terminal output is replayed at its original recorded timing.']),
 (18.,36.,'THE EXAMPLE','A small change.\nA real boundary.',
 ['Old:  if user.is_admin:','New: if user.is_admin or allow_preview:',
 'The text changed. The diff alone does not establish deployed access behavior.',
 'This is a terminal replay, not a browser UI recording.'])]
end=intro+cap
cards.extend([
 (end,end+post*.25,'THE ACTUAL RESPONSE','Observe the change.\nInspect both sources.',
 [f"One real qwen3.6:35b invocation completed in {live['provenance']['elapsed_seconds']:.3f} seconds.",
 'The returned observation cites the old and new line 20.',
 'It describes adding “or allow_preview” while retaining the existing check.',
 'This is one observed run, not a performance or accuracy guarantee.']),
 (end+post*.25,end+post*.50,'THE VALIDATOR','A valid citation\nis not proof of truth.',
 ['The actual response passed schema and reference validation.',
 'A separate, deliberately changed citation used an unknown evidence ID.',
 'The validator rejected that negative control with exit code 1.',
 'The original model response remained unchanged.']),
 (end+post*.50,end+post*.75,'SCOPE & PROVENANCE','The limits stay visible.',
 ['Changed text and exact coordinates; no repository code execution.',
 'No binary-content review, test execution or security certification.',
 'Exports preserve the response, evidence, validation and model provenance.',
 'Development QA uses synthetic examples and retained failures, not an independent benchmark.']),
 (end+post*.75,total,'LOCAL PROTOTYPE','Keep the evidence.\nKeep the final judgment.',
 ['Missing local runtime means inference unavailable; there is no cloud fallback.',
 'Broader evaluation, a reviewer study and full accessibility testing remain.',
 'The source cast, event log and actual result accompany this demonstration.',
 'EvidenceDesk · CLI demonstration · synthetic input · actual local inference'])])
frames=ROOT/'render-frames';frames.mkdir(exist_ok=True)

def wrapped(draw,s,f,width):
 out=[]
 for part in s.split('\n'):
  line=''
  for word in part.split():
   trial=(line+' '+word).strip()
   if draw.textlength(trial,font=f)>width and line:out.append(line);line=word
   else:line=trial
  out.append(line)
 return out

def base(label,t):
 im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
 d.line((68,74,124,74),fill=ACCENT,width=5);d.text((147,50),label,font=font(29,True),fill=ACCENT)
 d.text((1550,50),'EVIDENCEDESK',font=font(27,True),fill=MUTED)
 d.line((68,1022,1852,1022),fill='#254234',width=2)
 d.line((68,1022,68+1784*t/total,1022),fill=ACCENT,width=4)
 d.text((68,1038),'LOCAL PROTOTYPE  /  SYNTHETIC INPUT',font=font(19),fill=MUTED)
 d.text((1660,1038),f'{int(t)//60:02}:{int(t)%60:02} / {int(total)//60:02}:{int(total)%60:02}',font=font(19),fill=MUTED)
 return im,d

def card_frame(card,t):
 _,_,label,title,body=card;im,d=base(label,t);y=178
 for s in title.split('\n'):d.text((70,y),s,font=font(78,True),fill=INK);y+=94
 y+=55
 for i,s in enumerate(body):
  if label=='THE EXAMPLE' and i<2:
   d.rounded_rectangle((70,y-8,1848,y+58),radius=10,fill=PANEL)
   d.text((94,y),s,font=ImageFont.truetype(MONO,35),fill=ACCENT if i else MUTED);y+=86
  else:
   for line in wrapped(d,s,font(34),1690):d.text((75,y),line,font=font(34),fill=INK if i<2 else MUTED);y+=48
   y+=20
 return im

lines=[''];lastcommand=[];ci=0;ei=0

def add_output(s):
 global lines
 # The recorder emits screen clears; subprocess output otherwise contains plain text.
 s=s.replace('\r\n','\n')
 chunks=s.split('\x1b[2J\x1b[H')
 for j,part in enumerate(chunks):
  if j:lines=['']
  part=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',part)
  for c in part:
   if c=='\n':lines.append('')
   elif c=='\r':lines[-1]=''
   else:
    if len(lines[-1])>=110:lines.append('')
    lines[-1]+=c
  lines=lines[-27:]

def caption(command):
 if not command:return 'Recorded subprocess output. Commands, responses and reading pauses retain their actual timing.'
 joined=' '.join(command)
 if command[0]=='cat':return 'The synthetic diff retains user.is_admin and adds “or allow_preview” on the new line.'
 if 'evidence_pack.py' in joined:return 'The deterministic parser extracts evidence; it does not call AI or execute the changed code.'
 if 'local_review.py' in joined:return 'An actual local Ollama request is running. The waiting time is preserved at 1× speed.'
 if 'prepare-validation' in joined:return 'Create a separate negative control by changing a citation; preserve the original response.'
 if 'inspect_demo.py evidence' in joined:return 'Old and new line 20 have distinct reproducible evidence IDs.'
 if 'inspect_demo.py claim' in joined:return 'These are the actual model words and the source records referenced by this run.'
 if 'inspect_demo.py provenance' in joined:return 'Actual run provenance identifies the local model, elapsed time and absence of semantic truth verification.'
 if 'invalid-review.json' in joined:return 'Expected rejection: the deliberately unknown evidence ID does not exist in the pack.'
 if 'valid-review.json' in joined:return 'The actual review passes structural validation. That result does not verify semantic truth.'
 return 'This is actual terminal output, replayed from the timestamped capture.'

def terminal_frame(t):
 global ci,ei,lastcommand
 ct=t-intro
 while ci<len(cast) and cast[ci][0]<=ct+1e-7:add_output(cast[ci][2]);ci+=1
 while ei<len(events) and events[ei]['t']<=ct+1e-7:
  if events[ei]['kind']=='command_start':lastcommand=events[ei]['argv']
  ei+=1
 im,d=base('ACTUAL CLI RECORDING',t)
 d.text((70,118),'REPLAY AT 1× ORIGINAL TIMING',font=font(24,True),fill=ACCENT)
 d.text((1460,118),f'Capture +{ct:06.2f}s',font=font(25),fill=MUTED)
 d.rounded_rectangle((64,166,1856,922),radius=15,fill=PANEL,outline='#284637',width=2)
 for row,line in enumerate(lines[-27:]):
  color=ACCENT if line.startswith(('EvidenceDesk $','[process exit')) else INK
  d.text((91,181+row*27),line,font=mono,fill=color)
 for j,line in enumerate(wrapped(d,caption(lastcommand),font(26),1760)):
  d.text((72,942+j*33),line,font=font(26),fill=MUTED)
 return im

points={0,int(round(total*FPS)),int(round(intro*FPS)),int(round((intro+cap)*FPS))}
for c in cards:points.update((int(round(c[0]*FPS)),int(round(c[1]*FPS))))
for event in cast:points.add(int(math.ceil((intro+event[0])*FPS)))
for event in events:
 if event['kind']=='command_start':points.add(int(math.ceil((intro+event['t'])*FPS)))
for n in range(math.ceil(cap)):points.add(int(round((intro+n)*FPS)))
points=sorted(x for x in points if 0<=x<=round(total*FPS))
concat=[];timeline=[]
for i,frame in enumerate(points[:-1]):
 t=frame/FPS;duration=(points[i+1]-frame)/FPS
 if duration<=0:continue
 current=next((c for c in cards if c[0]<=t<c[1]),None)
 im=card_frame(current,t) if current else terminal_frame(t)
 name=f'{i:04}.png';im.save(frames/name)
 concat.extend([f"file 'render-frames/{name}'",f'duration {duration:.9f}'])
 timeline.append({'video_start':t,'duration':duration,'kind':'explanatory_card' if current else 'actual_terminal_replay','capture_time':None if current else round(t-intro,6),'frame':name})
concat.append(f"file 'render-frames/{name}'")
(ROOT/'frames.ffconcat').write_text('ffconcat version 1.0\n'+'\n'.join(concat)+'\n')
(ROOT/'render-timeline.json').write_text(json.dumps({'fps':FPS,'width':W,'height':H,'duration':total,'capture_video_start':intro,'capture_video_end':intro+cap,'original_capture_seconds':meta['duration_seconds'],'original_speed':True,'max_timestamp_quantization_seconds':2/FPS,'segments':timeline},indent=2)+'\n')
# English cards are burned into pixels; this sidecar provides a searchable transcript.
transcript=['# EvidenceDesk CLI demonstration transcript','', 'Actual timestamped terminal output is replayed at its original speed. This is not browser footage.','']
for c in cards:transcript.extend([f'## {c[0]:.2f}–{c[1]:.2f}s · {c[2]}',c[3].replace('\n',' '),'','\n\n'.join(c[4]),''])
(ROOT/'transcript.md').write_text('\n'.join(transcript))
cmd=['ffmpeg','-hide_banner','-loglevel','warning','-f','concat','-safe','0','-i',str(ROOT/'frames.ffconcat'),'-t',str(total),'-vf','fps=24,format=yuv420p','-c:v','libx264','-preset','fast','-crf','18','-movflags','+faststart','-metadata','title=EvidenceDesk - actual local CLI demonstration','-metadata','comment=Timestamped actual subprocess replay with explanatory cards. Synthetic input. No browser UI footage.','-y',str(ROOT/'evidencedesk-cli-demo.mp4')]
subprocess.run(cmd,check=True)
print(json.dumps({'video':'evidencedesk-cli-demo.mp4','duration':total,'capture_duration':cap,'actual_inference_seconds':live['provenance']['elapsed_seconds'],'png_snapshots':len(timeline),'audio':'none; English explanatory cards and captions'},indent=2))
